package com.cyl.app;

import lombok.Data;

@Data
public class MessageModel {
	
 private String type;
 
 private String message;
 
 String memberId;
 
 String deviceId;
 
 String code;
 
}
