package com.cyl.h5.domain.query;

import lombok.Data;

@Data
public class OrderH5Query {
    private Integer tab;
}
