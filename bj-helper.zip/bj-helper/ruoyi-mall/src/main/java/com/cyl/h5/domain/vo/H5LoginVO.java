package com.cyl.h5.domain.vo;

import lombok.Data;

/**
 * todo 写法不规范，可以简化，没必要造一个类来处理
 */
@Data
public class H5LoginVO {
    private String token;
}
