package com.cyl.h5.domain.form;

import lombok.Data;

@Data
public class H5LoginForm {
    /** 账号即手机号 */
    private String mobile;
}
