var sysConfig = {
    "softName": "萤火",
    "softVersion": "1.0.0",
    "serverUrl": "http://39.106.64.84",
    "wsurl": "ws://39.106.64.84/h5/ws/",
    "autoExecTask": true, // 是否自动执行任务
}

module.exports = sysConfig;